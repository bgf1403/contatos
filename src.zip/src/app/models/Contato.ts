export interface Contato {
    nome:string;
    email:string;
    telefones:string[]
}